﻿using Crud2.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Crud2.Controllers
{
    public class UserController : Controller
    {
        public AppdbContext dbcontext;

        public UserController(AppdbContext context)
        {
            dbcontext = context;
        }
        public IActionResult Index()
        {
            var user = dbcontext.Users.ToList();
            return View(user);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(User user)
        {
            dbcontext.Users.Add(user);
            dbcontext.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Update(int id)
        {
            var emp = dbcontext.Users.Find(id);
            return View(emp);
        }
        [HttpPost]
        public IActionResult Update(User user)
        {
            dbcontext.Users.Update(user);
            dbcontext.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
             var emp = dbcontext.Users.SingleOrDefault(e=>e.Id == id);
            dbcontext.Users.Remove(emp);
            dbcontext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}

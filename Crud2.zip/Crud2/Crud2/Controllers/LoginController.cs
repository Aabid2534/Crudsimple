﻿using Crud2.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Crud2.Controllers
{
    public class LoginController : Controller
    {
        public AppdbContext dbcontext;

        public LoginController(AppdbContext context)
        {
            dbcontext = context;
        }
        public IActionResult Index()
        {
            var emp = dbcontext.logins.ToList();
            return View(emp);
        }
    }
}

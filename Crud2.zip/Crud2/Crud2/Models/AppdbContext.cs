﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Crud2.Models;
namespace Crud2.Models
{
    public class AppdbContext:DbContext
    {
        public AppdbContext(DbContextOptions<AppdbContext>option) : base(option) { }

        public DbSet<User> Users { get; set; }

        public DbSet<Login> logins { get; set; }
    }
}
